select count(associate_id),start_date
from associate_status value
group by start_date;

select count(associate_id),start_date
from associate_status value
where trainer_id='F001'
group by start_date;

select count(associate_id),start_date
from associate_status value
where trainer_id='F001'
group by start_date
having count(associate_id)>2;

select module_name, module_duration
from module_info value
order by module_duration;

select
associate_name,module_name,module_duration
from associate_info,associate_status,module_info
order by module_duration desc;
