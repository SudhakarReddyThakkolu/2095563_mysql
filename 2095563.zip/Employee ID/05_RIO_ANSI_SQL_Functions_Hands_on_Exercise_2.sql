select upper(student_name), upper(branch) from student_info;


select lower( subject_code), lower(subject_name) from subjects_info;



select date_format(date_of_birth, '%b %d, %Y') from student_info;
select date_format(date_of_birth, '%Y/%m/%d') from student_info;



select student_name, contact, email_id, year(current_date())-year(date_of_birth) as student_age from student_info;



select si.registration_number, si.student_name, sm.semester , avg(sm.marks) from student_info as si
inner join student_marks as sm on si.registration_number = sm.registration_number group by sm.semester;



select si.student_name, si.registration_number, max(sm.marks) from student_info as si inner join
student_marks as sm on si.registration_number = sm.registration_number;


select si.student_name, si.registration_number, max(sm.marks) from student_info as si inner join
student_marks as sm on si.registration_number = sm.registration_number where sm.subject_code = 'EI05IP';



select semester, avg(gpa)
from student_result group by semester;



select email_id(if null(email_id,no_valid_email_address))
from student_info;