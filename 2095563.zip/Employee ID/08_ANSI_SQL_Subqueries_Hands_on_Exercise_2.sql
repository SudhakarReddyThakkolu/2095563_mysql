select distinct trainer_id from associate_status
 where Associate_Id in (select Associate_Id from associate_info where Associate_Name like '%i%');
 
 select distinct trainer_id from associate_status
 where Associate_Id in (select Associate_Id from associate_info where Associate_Name not like '%i%');
 
 select trainer_id, trainer_rating from trainer_feedback
where trainer_id in (select trainer_id from associate_status where module_Id = 'J2EE');

insert into trainer_info select * from trainer_info_sabbatical;

update trainer_info set trainer_location = 'kochi'
 where trainer_id in (select trainer_id from trainer_info_sabbatical where Trainer_Experiance >10);
 
 delete from trainer_info where trainer_id
in (select trainer_id from trainer_info_sabbatical where Trainer_Experiance > 12);

select * from trainer_info_sabbatical as t1 where t1.trainer_id in
(select trainer_id from trainer_info as t2 where t1.Trainer_Id = t2.trainer_id);
