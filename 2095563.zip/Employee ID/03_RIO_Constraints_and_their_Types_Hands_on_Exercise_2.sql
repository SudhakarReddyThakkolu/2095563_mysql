create database 03_RIO_Constraints_and_their_Types_Hands_on_Exercise_2;
use 03_RIO_Constraints_and_their_Types_Hands_on_Exercise_2;
create table Student_Info(
Reg_Number varchar(20) primary key,
Student_Name varchar(30) not null,
Branch varchar(30),
Contact_Number varchar(30),
Date_of_Birth varchar(15),
Date_of_joining datetime default current_timestamp
);

create table Subject_Master(
Subject_Code varchar(20) primary key,
Subject_Name varchar(20) not null,
Weightage int not null
);

create table Student_Marks(
Reg_Number varchar(20),
foreign key (Reg_Number) REFERENCES Student_Info(Reg_Number),
Subject_Code varchar(20),
foreign key (Subject_Code) REFERENCES Subject_Master(Subject_Code),
Semester int,
Marks int
);

create table Student_Result(
Reg_Number varchar(20),
foreign key (Reg_Number) REFERENCES Student_Info(Reg_Number),
Semester int,
GPA double,
Is_Eligible varchar(4) default 'yes'
);

alter table subject_master
modify Subject_Name varchar(20) not null unique;

alter table student_info
modify Contact_Number varchar(30) unique;

alter table student_info
 ADD CHECK (Date_of_birth < date_of_joining);
 
alter table student_marks
ADD CHECK (Marks<=100);

alter table student_result
add check (GPA<=10);

alter table student_result
add check (Is_Eligible='Y' or Is_Eligible='N');


